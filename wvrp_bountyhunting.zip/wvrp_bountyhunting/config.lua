Config = {}

Config.HuntingMessage = 'Press [E] To Go Bounty Hunting'
Config.KillingMessage = 'Kill the fugitive for a cash prize'
Config.Price = 10
Config.Xp = 10