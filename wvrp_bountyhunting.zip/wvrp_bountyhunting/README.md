# Blueberry_hunt
That is hunting script. Just go to STAWBERRY and that have blip on the mini map, go to house and starting hunt by pressing DELETE. After Hunting you will get XP and Money. So that have a config file, there you can change money and xp and language of message.
